# KRISHN AI STUDIO

Mobile-friendly Streamlit starter app inside the existing agents-cli repository. Original Google Agents CLI files are kept unchanged.

## Run locally
1. Install Python 3.11+.
2. Open this folder in a terminal.
3. Run `pip install -r requirements.txt`.
4. Copy `.env.example` to `.env` and add API keys locally.
5. Run `streamlit run app.py`.

## Streamlit Community Cloud
- Repository: `kc816154-gif/agents-cli`
- Branch: `main`
- Main file path: `studio/app.py`
- Dependencies: `studio/requirements.txt`
- Add API keys under App Settings → Secrets.

Example:
```toml
OPENAI_API_KEY = "your-key"
ANTHROPIC_API_KEY = "your-key"
GITHUB_TOKEN = "your-token"
REPLICATE_API_TOKEN = "your-token"
```

## Included MVP
- OpenAI chat
- Claude chat
- OpenAI image generation
- Video prompt workflow and provider configuration check
- GitHub repository metadata lookup
- SQLite social content draft planner
- Website starter prompt generator
- Craft tools directory

Video generation needs a selected model/version and provider integration. Instagram, Facebook and YouTube publishing need official API access, OAuth permissions and platform compliance. SocialCraft currently saves drafts only; it does not auto-publish.

Never commit real API keys. Keep the original repository files and skills unchanged.
