import os, sqlite3
from datetime import date, datetime
from pathlib import Path
import requests
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
DB = Path(__file__).parent / "studio.db"
st.set_page_config(page_title="KRISHN AI STUDIO", page_icon="✨", layout="wide")
st.markdown("""
<style>
.stApp{background:radial-gradient(circle at 80% 0%,#172554 0,#090d18 40%);color:#f8fafc}
section[data-testid="stSidebar"]{background:#101827}
.hero{padding:28px;border:1px solid #334155;border-radius:20px;background:linear-gradient(120deg,#172554,#111827,#312e81)}
.hero h1{font-size:2.3rem;color:white;margin:0}.hero p{color:#cbd5e1}
.tile{padding:16px;border:1px solid #334155;border-radius:16px;background:#111827;min-height:100px}
</style>
""",unsafe_allow_html=True)

def db():
    c=sqlite3.connect(DB)
    c.execute("CREATE TABLE IF NOT EXISTS drafts(id INTEGER PRIMARY KEY,platform TEXT,title TEXT,caption TEXT,publish_date TEXT,status TEXT,created_at TEXT)")
    c.commit()
    return c

def openai_chat(prompt,history):
    key=os.getenv("OPENAI_API_KEY")
    if not key: return "OPENAI_API_KEY missing. Add it in Streamlit Secrets or studio/.env."
    msgs=[{"role":"system","content":"You are KRISHN AI STUDIO, a helpful multilingual creative and coding assistant."}]+history[-10:]+[{"role":"user","content":prompt}]
    r=requests.post("https://api.openai.com/v1/chat/completions",headers={"Authorization":"Bearer "+key},json={"model":os.getenv("OPENAI_MODEL","gpt-4o-mini"),"messages":msgs},timeout=90)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]

def claude_chat(prompt):
    key=os.getenv("ANTHROPIC_API_KEY")
    if not key: return "ANTHROPIC_API_KEY missing. Add it in Streamlit Secrets or studio/.env."
    r=requests.post("https://api.anthropic.com/v1/messages",headers={"x-api-key":key,"anthropic-version":"2023-06-01","content-type":"application/json"},json={"model":os.getenv("CLAUDE_MODEL","claude-3-5-haiku-latest"),"max_tokens":1600,"messages":[{"role":"user","content":prompt}]},timeout=90)
    r.raise_for_status()
    return "".join(x.get("text","") for x in r.json().get("content",[]))

st.sidebar.title("✨ KRISHN AI STUDIO")
st.sidebar.caption("ONE AI. ALL SKILLS. ONE STUDIO.")
page=st.sidebar.radio("WORKSPACE",["Dashboard","AI Chat","Claude AI","PhotoCraft","FilmCraft","GitHub Agent","SocialCraft","WebsiteCraft","Craft Tools","Settings"])

if page=="Dashboard":
    st.markdown('<div class="hero"><h1>KRISHN AI STUDIO</h1><p>Your all-in-one creative and AI workspace.</p></div>',unsafe_allow_html=True)
    st.write("")
    cols=st.columns(3)
    for col,title,desc in zip(cols,["🤖 AI Assistant","🎨 PhotoCraft","🎬 FilmCraft"],["ChatGPT-powered chat","Text-to-image generation","AI video workflow"]):
        with col: st.markdown(f'<div class="tile"><b>{title}</b><p>{desc}</p></div>',unsafe_allow_html=True)
    st.subheader("Modules")
    st.write("ChatGPT • Claude • GitHub • Image • Video • Website • Social Media • Documents • Automation")
    st.info("Open Settings to check API configuration. Paid API usage may apply.")

elif page=="AI Chat":
    st.title("🤖 AI Chat")
    if "history" not in st.session_state: st.session_state.history=[]
    for m in st.session_state.history:
        with st.chat_message(m["role"]): st.markdown(m["content"])
    p=st.chat_input("Ask KRISHN AI...")
    if p:
        st.session_state.history.append({"role":"user","content":p})
        with st.chat_message("user"): st.write(p)
        with st.chat_message("assistant"):
            try:
                ans=openai_chat(p,st.session_state.history[:-1]); st.markdown(ans)
                st.session_state.history.append({"role":"assistant","content":ans})
            except Exception as e: st.error(f"OpenAI error: {e}")

elif page=="Claude AI":
    st.title("🧠 Claude AI")
    p=st.text_area("Your prompt",height=180)
    if st.button("Ask Claude",type="primary",disabled=not bool(p.strip())):
        try: st.markdown(claude_chat(p))
        except Exception as e: st.error(f"Claude error: {e}")

elif page=="PhotoCraft":
    st.title("🎨 PhotoCraft – Image Generator")
    p=st.text_area("Describe your image",height=140,placeholder="Cinematic product photo, detailed lighting...")
    st.caption("Uses OpenAI image API; generation may incur charges.")
    if st.button("Generate image",type="primary",disabled=not bool(p.strip())):
        key=os.getenv("OPENAI_API_KEY")
        if not key: st.error("Add OPENAI_API_KEY in Settings.")
        else:
            try:
                with st.spinner("Generating..."):
                    r=requests.post("https://api.openai.com/v1/images/generations",headers={"Authorization":"Bearer "+key},json={"model":"gpt-image-1","prompt":p,"size":"1024x1024"},timeout=180)
                    r.raise_for_status(); item=r.json()["data"][0]
                    if item.get("b64_json"):
                        import base64
                        data=base64.b64decode(item["b64_json"]); st.image(data)
                        st.download_button("Download PNG",data,"krishn-image.png","image/png")
                    elif item.get("url"): st.image(item["url"])
                    else: st.warning("No image data returned.")
            except Exception as e: st.error(f"Image error: {e}")

elif page=="FilmCraft":
    st.title("🎬 FilmCraft – Video Studio")
    p=st.text_area("Describe your video",height=140)
    ratio=st.selectbox("Format",["9:16 Reels","16:9 YouTube","1:1 Square"])
    st.info("Video rendering needs a selected provider/model, API token and credits. This MVP prepares the workflow; it does not fake a finished video.")
    if st.button("Prepare video job"):
        if not p.strip(): st.warning("Enter a video prompt.")
        elif not os.getenv("REPLICATE_API_TOKEN"): st.warning("Add REPLICATE_API_TOKEN in Streamlit Secrets before connecting a Replicate model.")
        else: st.success("Video prompt prepared. Provider model/version integration is the next build step. Format: "+ratio)

elif page=="GitHub Agent":
    st.title("🐙 GitHub Agent")
    repo=st.text_input("Repository","kc816154-gif/agents-cli")
    if st.button("Inspect repository"):
        headers={"Accept":"application/vnd.github+json"}
        if os.getenv("GITHUB_TOKEN"): headers["Authorization"]="Bearer "+os.getenv("GITHUB_TOKEN")
        try:
            r=requests.get("https://api.github.com/repos/"+repo,headers=headers,timeout=30); r.raise_for_status(); d=r.json()
            st.success(d["full_name"]+" • Branch: "+d["default_branch"])
            st.write(d.get("description") or "No description")
            st.link_button("Open GitHub",d["html_url"])
        except Exception as e: st.error(f"GitHub error: {e}")
    st.caption("This first version reads repository metadata only. Write operations will require scoped authorization and confirmation.")

elif page=="SocialCraft":
    st.title("📱 SocialCraft – Content Planner")
    st.caption("Save drafts and planned dates. Automatic publishing is not enabled yet.")
    with st.form("draft"):
        platform=st.selectbox("Platform",["Instagram","YouTube","Facebook"])
        title=st.text_input("Title")
        caption=st.text_area("Caption and hashtags")
        day=st.date_input("Planned date",value=date.today())
        submit=st.form_submit_button("Save draft")
    if submit:
        if title.strip():
            c=db(); c.execute("INSERT INTO drafts(platform,title,caption,publish_date,status,created_at) VALUES(?,?,?,?,?,?)",(platform,title,caption,str(day),"Draft",datetime.utcnow().isoformat())); c.commit(); c.close()
            st.success("Draft saved.")
        else: st.warning("Title is required.")
    c=db(); rows=c.execute("SELECT platform,title,caption,publish_date,status FROM drafts ORDER BY id DESC").fetchall(); c.close()
    st.subheader("Saved drafts")
    for platform,title,caption,day,status in rows:
        with st.expander(f"{day} • {platform} • {title}"):
            st.write(caption); st.caption(status)
    if not rows: st.info("No drafts yet.")

elif page=="WebsiteCraft":
    st.title("🌐 WebsiteCraft")
    idea=st.text_area("Describe your website")
    if st.button("Create website prompt",disabled=not bool(idea.strip())):
        st.code("Build a mobile-first, responsive website for: "+idea+" Include accessible components, SEO metadata, clean design, and setup instructions.",language="text")
    st.info("Use AI Chat to generate the actual HTML/CSS/JavaScript project. ZIP export is planned.")

elif page=="Craft Tools":
    st.title("🧰 Craft Tools")
    items={"VectorCraft":"Logo and SVG workflows","LightCraft":"Image enhancement","EffectCraft":"Video effects","DesignCraft":"Posters and thumbnails","SoundCraft":"Voice and audio workflows","PdfCraft":"PDF tools","WordCraft":"Documents","DeckCraft":"Presentations","GridCraft":"Spreadsheets","CADCraft":"CAD design workflows"}
    cols=st.columns(2)
    for i,(name,desc) in enumerate(items.items()):
        with cols[i%2]: st.markdown(f'<div class="tile"><b>{name}</b><p>{desc}</p></div>',unsafe_allow_html=True); st.write("")

elif page=="Settings":
    st.title("⚙️ API Settings")
    st.warning("Never put real API keys in source code or public GitHub files.")
    for key,label in [("OPENAI_API_KEY","OpenAI"),("ANTHROPIC_API_KEY","Claude"),("GITHUB_TOKEN","GitHub"),("REPLICATE_API_TOKEN","Video provider")]:
        st.write(label+": "+("✅ Configured" if os.getenv(key) else "Not configured"))
    st.markdown("For Streamlit Cloud, add keys in App → Settings → Secrets.")
    st.code('OPENAI_API_KEY = "your-key"\nANTHROPIC_API_KEY = "your-key"\nGITHUB_TOKEN = "your-token"\nREPLICATE_API_TOKEN = "your-token"',language="toml")
